package com.shopify.shopifyapp.login;
import com.google.gson.JsonElement;
import com.shopify.shopifyapp.utils.ApiCallInterface;
import io.reactivex.Observable;
public class Repository {

    private ApiCallInterface apiCallInterface;

    public Repository(ApiCallInterface apiCallInterface) {
        this.apiCallInterface = apiCallInterface;
    }

    /*
     * method to call login api
     * */
    public Observable<JsonElement> executeLogin(String mobileNumber, String password) {
        return apiCallInterface.login(mobileNumber, password);
    }

}
