package com.shopify.shopifyapp;
import android.app.Application;
import android.content.Context;
import com.shopify.shopifyapp.di.AppComponent;
import com.shopify.shopifyapp.di.AppModule;
import com.shopify.shopifyapp.di.DaggerAppComponent;
import com.shopify.shopifyapp.di.UtilsModule;

public class MyApplication extends Application {
    AppComponent appComponent;
    Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        appComponent = DaggerAppComponent.builder().appModule(new AppModule(this)).utilsModule(new UtilsModule()).build();
    }

    public AppComponent getAppComponent() {
        return appComponent;
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }
}
