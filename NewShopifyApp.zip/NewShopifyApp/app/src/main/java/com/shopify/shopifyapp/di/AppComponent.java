package com.shopify.shopifyapp.di;


import com.shopify.shopifyapp.login.LoginActivity;

import javax.inject.Singleton;

import dagger.Component;

@Component(modules = {AppModule.class, UtilsModule.class})
@Singleton
public interface AppComponent {

    void doInjection(LoginActivity loginActivity);

}
