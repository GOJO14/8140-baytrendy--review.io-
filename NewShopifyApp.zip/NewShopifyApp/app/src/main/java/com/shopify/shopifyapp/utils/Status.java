package com.shopify.shopifyapp.utils;

public enum Status {
    LOADING,
    SUCCESS,
    ERROR
}